# Afolashade Joy Jubrilla — Personal Website

This repository contains my personal website, showcasing my experience as a KYC Analyst and AML specialist based in Rotterdam, Netherlands.